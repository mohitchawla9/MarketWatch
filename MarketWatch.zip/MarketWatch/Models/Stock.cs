﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MarketWatch.Models
{
    public class Stock
    {
        public int StockID { get; set; }
        public string StockName { get; set; }
        public float StartingPrice { get; set; }
        public float CurrentPrice { get; set; }

        public List<Stock> GetHardCodedValues()
        {
            var returnModel = new List<Stock>();

            var firstStock = new Stock()
            {
                StockName = "Rel",
                StartingPrice = 100,
                CurrentPrice = 102
            };
            var secondStock = new Stock()
            {
                StockName = "Tata",
                StartingPrice = 104,
                CurrentPrice = 102
            };
            var thirdStock = new Stock()
            {
                StockName = "Infosys",
                StartingPrice = 106,
                CurrentPrice = 102
            };

            returnModel.Add(firstStock);
            returnModel.Add(secondStock);
            returnModel.Add(thirdStock);

            return returnModel;
        }
    }

   
}
