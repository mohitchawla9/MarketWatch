﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using X.PagedList;

namespace MarketWatch.Models
{
    public class MarketPaginginfo
    {
        public int? pageSize;
        public StaticPagedList<Stock> Stocks { get; set; }
    }
}
