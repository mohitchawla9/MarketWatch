﻿namespace MarketWatch.Controllers
{
    public class Param
    {
        public string nameInp { get; set; }
    }
}