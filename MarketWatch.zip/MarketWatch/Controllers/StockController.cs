﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MarketWatch.Repository;
using MarketWatch.Models;
using X.PagedList;

namespace MarketWatch.Controllers
{
    public class StockController : Controller
    {
        IMarket _IMarket;

        public StockController(IMarket IMarket)
        {
            _IMarket = IMarket;
        }

        [HttpGet]
        public IActionResult Market(int? page = 1)
        { 
            MarketPaginginfo marketPaginginfo = new MarketPaginginfo();
            if (page < 0)
            {
                page = 1;
            }

            var pageIndex = (page ?? 1) - 1;
            var pageSize = 5;

            int totalStockCount = _IMarket.GetStockCount();
            var markets = _IMarket.MarketPagination(page, pageSize).ToList();
            var marketPagedList = new StaticPagedList<Stock>(markets, pageIndex + 1, pageSize, totalStockCount);
            marketPaginginfo.Stocks = marketPagedList;
            marketPaginginfo.pageSize = page;
            return View(marketPaginginfo);

        }
          
        public IActionResult Insert(int? stockId)
        {
            _IMarket.Create(stockId);
            return RedirectToAction("Market");
        }

       
        

        
    }
}
