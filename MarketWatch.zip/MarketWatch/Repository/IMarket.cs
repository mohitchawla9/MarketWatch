﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MarketWatch.Models;

namespace MarketWatch.Repository
{
    public interface IMarket
    {
        public int GetStockCount();
        List<Stock> MarketPagination(int? page, int pageSize);
        bool Create(int? stockId);
    }
}
