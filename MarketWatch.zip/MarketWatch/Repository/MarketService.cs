﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MarketWatch.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections;
using System.Net.Http;
using System.Net;
using Newtonsoft.Json.Linq;
using System.IO;
using MarketWatch.Models;
using MarketWatch.Controllers;

namespace MarketWatch.Repository
{
    public class MarketService : IMarket
    {
        public static List<Stock> stocks = new List<Stock>()
        {
            new Stock(){StockName = "Rel" , StockID = 1,StartingPrice = 2233 , CurrentPrice = 2134}
        };
        public int GetStockCount()
        {
            return stocks.Count;
        }

        public List<Stock> MarketPagination(int? page, int pageSize)
        { 
            return stocks;
        }

        private float GetPrice(string param)
        {
            string token = "";
            string url = String.Format("", param, token);

            var res = GetData(url);

            if (res == null)
            {
                return -1;
            }

            JObject json = JObject.Parse(res);

            if (json["latestPrice"] == null)
            {
                return -1;
            }

            float price = (float)json["latestPrice"];
            return price;
        }

        public bool Create(int? stockId)
        {
            int index = stocks.FindIndex(x => x.StockID == stockId);
            if (index > -1)
            {
                return false;
            }

            float price = 10;//GetPrice(stockId);
            if (price < 0)
            {
                return false;
            }

            stocks.Add(new Stock() { StockID = 2, StockName = "Mohit", CurrentPrice =800, StartingPrice = 900 });

            return true;
        }

        public static string GetData(string url)
        {
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";

            try
            {
                using var webResponse = request.GetResponse();
                using var webStream = webResponse.GetResponseStream();

                using var reader = new StreamReader(webStream);
                var data = reader.ReadToEnd();
                return data;
            }
            catch (Exception e)
            {
                return "";
            }
        }
        //public IEnumerable<Stock> Get()
        //{
        //    //grab the latest stock infomration
        //    foreach (var stock in stocks)
        //    {
        //        //float price = GetPrice(stock.StockName);
        //        //if (price < 0f)
        //        //{
        //        //    price = 0;
        //        //}

        //        //stock.CurrentPrice = price;
        //        //stock.Diff.Add(((stock.PriceNow - stock.StartingPrice) / (stock.StartingPrice / 100)) / 100);
        //    }
        //    return stocks;
        //}
    }
}
